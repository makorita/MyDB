import java.io.*;
import java.util.*;
import java.util.regex.*;

public class Jikkou02_MakeIfAccessList{
	static String headerStr="ホスト名,interface,in/out,rawConfig,シーケンス番号,acl番号,許可_拒否,プロトコル,送信元IP,送信元ワイルドカード,送信元オプション,宛先IP,宛先ワイルドカード,宛先オプション,remark文字列";
	
	public static void main(String[] args) throws Exception{
		//コンフィグリストの取得
		File rootDir=new File("../02_rawConfig");
		File[] configList=rootDir.listFiles();
		
		for(File curFile:configList){	//ファイル回し
			//ホスト名取得
			String hostname=getHostname(curFile);
			if(hostname.matches(".*FW.*"))continue;
			System.out.println(curFile.getName());	//処理ファイル名
			
			/*
			//access-list番号取得
			String inAclNum=getInAclNum(curFile);
			if(inAclNum==null)continue;
			String outAclNum=getOutAclNum(curFile);
			if(outAclNum==null)continue;
			*/
			
			HashMap aclIfMap=getAclI_FMap(curFile);
			
			LinkedList<String> outputList=new LinkedList<String>();
			
			//標準アクセスリスト
			{
				String acl_regex="access-list( \\d{1,2})( permit| deny *)( \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}| host \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}| \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3} \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}| any)";
				Pattern acl_p = Pattern.compile(acl_regex);
				String remark_regex="access-list( \\d{1,2}) remark (.*)";
				Pattern remark_p=Pattern.compile(remark_regex);
				
				BufferedReader br = new BufferedReader(new FileReader(curFile));
				String remarkStr=null;
				String aclNum=null;
				int seqNum=-1;
				String line;
				while ((line = br.readLine()) != null) {
					if(!line.matches("access-list \\d{1,2} .*"))continue;
					
					Matcher m=null;
					if(line.matches(".* remark .*"))m=remark_p.matcher(line);
					else m=acl_p.matcher(line);
					if(!m.find()){
						System.out.println("想定外のaccess-list:"+line);
						System.exit(0);
					}
					
					//ACL番号取得
					if(aclNum==null || !aclNum.equals(m.group(1).replaceAll(" ",""))){
						aclNum=m.group(1).replaceAll(" ","");
						seqNum=10;
					}
					
					//出力文字列生成
					String outputStr=null;
					outputStr=hostname;
					outputStr+=",,";
					outputStr+=","+line;
					outputStr+=","+seqNum;
					seqNum+=10;
					outputStr+=","+aclNum;
					if(line.matches(".*remark .*")){
						remarkStr=m.group(2);
						outputStr+=",remark,,,,,,,,"+remarkStr;
						outputList.add(outputStr);
						continue;
					}
					
					outputStr+=","+m.group(2).replaceAll(" ","");
					outputStr+=",";
					String[] word=m.group(3).split(" ");
					if(word[1].equals("host")){
						outputStr+=","+word[2]+",0.0.0.0";
					}else if(word.length==2){
						outputStr+=","+word[1]+",0.0.0.0";
					}else if(word[1].equals("any")){
						outputStr+=",0.0.0.0,255.255.255.255";
					}else{
						outputStr+=","+word[1]+","+word[2];
					}
					outputStr+=",,,,";
					outputStr+=","+remarkStr;
					outputList.add(outputStr);
				}
				br.close();
			}
			
			//拡張アクセスリスト
			{
				String acl_regex="access-list( \\d+)( permit| deny *)( tcp| udp| icmp| ip| esp| gre| 112)( host \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}| \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3} \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}| any)(.*?)( host \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}| \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3} \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}| any)(.*)";
				Pattern acl_p = Pattern.compile(acl_regex);
				String remark_regex="access-list( \\d+) remark (.*)";
				Pattern remark_p=Pattern.compile(remark_regex);
				
				BufferedReader br = new BufferedReader(new FileReader(curFile));
				String remarkStr=null;
				String aclNum=null;
				int seqNum=-1;
				String line;
				while ((line = br.readLine()) != null) {
					if(line.matches("access-list \\d{1,2} .*"))continue;
					if(!line.matches("access-list .*"))continue;
					
					Matcher m=null;
					if(line.matches(".* remark .*"))m=remark_p.matcher(line);
					else m=acl_p.matcher(line);
					if(!m.find()){
						System.out.println("想定外のaccess-list:"+line);
						System.exit(0);
					}
					
					//ACL番号取得
					if(aclNum==null || !aclNum.equals(m.group(1).replaceAll(" ",""))){
						aclNum=m.group(1).replaceAll(" ","");
						seqNum=10;
					}
					
					//出力文字列生成
					String outputStr=null;
					outputStr=hostname;
					if(aclIfMap.containsKey(aclNum))outputStr+=","+aclIfMap.get(aclNum);
					else outputStr+=",,";
					outputStr+=","+line;
					outputStr+=","+seqNum;
					seqNum+=10;
					outputStr+=","+aclNum;
					if(line.matches(".*remark .*")){
						remarkStr=m.group(2);
						outputStr+=",remark,,,,,,,,"+remarkStr;
						outputList.add(outputStr);
						continue;
					}
					
					outputStr+=","+m.group(2).replaceAll(" ","");
					outputStr+=","+m.group(3).replaceAll(" ","");
					String[] word=m.group(4).split(" ");
					if(word[1].equals("host")){
						outputStr+=","+word[2]+",0.0.0.0";
					}else if(word[1].equals("any")){
						outputStr+=",0.0.0.0,255.255.255.255";
					}else{
						outputStr+=","+word[1]+","+word[2];
					}
					outputStr+=","+m.group(5);
					word=m.group(6).split(" ");
					if(word[1].equals("host")){
						outputStr+=","+word[2]+",0.0.0.0";
					}else if(word[1].equals("any")){
						outputStr+=",0.0.0.0,255.255.255.255";
					}else{
						outputStr+=","+word[1]+","+word[2];
					}
					outputStr+=","+m.group(7);
					outputStr+=","+remarkStr;
					outputList.add(outputStr);
				}
				br.close();
			}
			
			//新版アクセスリスト
			{
				String standard_regex="( \\d+)*( permit| deny *)( host \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}| \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3} \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}| any)";
				Pattern standard_p = Pattern.compile(standard_regex);
				String extended_regex="( \\d+)*( permit| deny *)( tcp| udp| icmp| ip)( host \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}| \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3} \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}| any)(.*?)( host \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}| \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3} \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}| any)(.*)";
				Pattern extended_p = Pattern.compile(extended_regex);
				String remark_regex="( \\d+)* remark (.*)";
				Pattern remark_p=Pattern.compile(remark_regex);
				
				BufferedReader br = new BufferedReader(new FileReader(curFile));
				String line;
				String mode="ACL_OUT";
				String remarkStr=null;
				int seqNum=-1;
				String aclNum=null;
				while ((line = br.readLine()) != null) {
					String outputStr=null;
					if(line.matches("ip access-list (extended|standard) .*")){
						seqNum=10;
						aclNum=line.replaceAll("ip access-list (extended|standard) ","");
						outputStr=hostname;
						if(aclIfMap.containsKey(aclNum))outputStr+=","+aclIfMap.get(aclNum);
						else outputStr+=",,";
						outputStr+=","+line;
						outputStr+=",,"+aclNum;
						outputStr+=",,,,,,,,,";
						outputList.add(outputStr);
						//System.out.println(outputStr);
						mode="ACL_IN";
						continue;
					}
					if(mode.equals("ACL_OUT"))continue;
					
					Matcher m = standard_p.matcher(line);
					mode="ACL_STD";
					if(!m.find()){
						m = extended_p.matcher(line);
						mode="ACL_EXT";
						if(!m.find()){
							m = remark_p.matcher(line);
							mode="ACL_RMK";
							if(!m.find()){
								mode="ACL_OUT";
								continue;
							}
						}
					}
					
					//出力文字列生成
					outputStr=hostname;
					if(aclIfMap.containsKey(aclNum))outputStr+=","+aclIfMap.get(aclNum);
					else outputStr+=",,";
					outputStr+=","+line;
					if(m.group(1)!=null){
						outputStr+=","+m.group(1);
					}else{
						outputStr+=","+seqNum;
						if(!mode.equals("ACL_RMK"))seqNum+=10;
					}
					outputStr+=","+aclNum;
					if(mode.equals("ACL_RMK")){
						remarkStr=m.group(2);
						outputStr+=",remark,,,,,,,,"+remarkStr;
						outputList.add(outputStr);
						//System.out.println(outputStr);
						continue;
					}
					
					outputStr+=","+m.group(2).replaceAll(" ","");
					if(mode.equals("ACL_STD")){
						outputStr+=",";
						String[] word=m.group(3).split(" ");
						if(word[1].equals("host")){
							outputStr+=","+word[2]+",0.0.0.0";
						}else if(word[1].equals("any")){
							outputStr+=",0.0.0.0,255.255.255.255";
						}else{
							outputStr+=","+word[1]+","+word[2];
						}
						outputStr+=",,,,";
						outputStr+=","+remarkStr;
						outputList.add(outputStr);
						//System.out.println(outputStr);
						continue;
					}
					
					outputStr+=","+m.group(3).replaceAll(" ","");
					String[] word=m.group(4).split(" ");
					if(word[1].equals("host")){
						outputStr+=","+word[2]+",0.0.0.0";
					}else if(word[1].equals("any")){
						outputStr+=",0.0.0.0,255.255.255.255";
					}else{
						outputStr+=","+word[1]+","+word[2];
					}
					outputStr+=","+m.group(5);
					word=m.group(6).split(" ");
					if(word[1].equals("host")){
						outputStr+=","+word[2]+",0.0.0.0";
					}else if(word[1].equals("any")){
						outputStr+=",0.0.0.0,255.255.255.255";
					}else{
						outputStr+=","+word[1]+","+word[2];
					}
					outputStr+=","+m.group(7);
					outputStr+=","+remarkStr;
					outputList.add(outputStr);
					//System.out.println(outputStr);
				}
				br.close();
			}
			
			//設定が無いときは出力しない
			if(outputList.size()==0)continue;
			
			PrintWriter wr = new PrintWriter(new BufferedWriter(new OutputStreamWriter(new FileOutputStream("../10_acl/"+hostname+"_ACL.csv"),"Shift-JIS")));
			wr.println(headerStr);
			for(String curStr:outputList){
				wr.println(curStr);
			}
			wr.close();
		}
	}
	
	public static HashMap<String,String> getAclI_FMap(File curFile) throws Exception{
		HashMap<String,String> aclIfMap=new HashMap<String,String>();
		
		BufferedReader br = new BufferedReader(new FileReader(curFile));
		
		String line;
		String curIf=null;
		Pattern p = Pattern.compile(" ip access-group (.+) (in|out)");
		while ((line = br.readLine()) != null) {
			//System.out.println(line);
			
			if(line.matches("interface .*")){
				curIf=line;
				curIf=curIf.replace("interface ","");
				continue;
			}
			
			Matcher m = p.matcher(line);
			if(m.find()){
				String valueStr=curIf+","+m.group(2);
				aclIfMap.put(m.group(1),valueStr);
				//System.out.println(curIf+","+valueStr);
			}
		}
		br.close();
		
		return aclIfMap;
	}
	
	/*
	//in方向のaccess-list番号取得
	public static String getInAclNum(File curFile) throws Exception{
		BufferedReader br = new BufferedReader(new FileReader(curFile));
		
		String line;
		while ((line = br.readLine()) != null) {
			//System.out.println(line);
			if(line.matches(" ip access-group .+ in")){
				String returnStr=line;
				returnStr=returnStr.replace(" ip access-group ","");
				returnStr=returnStr.replace(" in","");
				return returnStr;
			}
		}
		br.close();
		
		return null;
	}
	
	//out方向のaccess-list番号取得
	public static String getOutAclNum(File curFile) throws Exception{
		BufferedReader br = new BufferedReader(new FileReader(curFile));
		
		String line;
		while ((line = br.readLine()) != null) {
			//System.out.println(line);
			if(line.matches(" ip access-group .+ out")){
				String returnStr=line;
				returnStr=returnStr.replace(" ip access-group ","");
				returnStr=returnStr.replace(" out","");
				return returnStr;
			}
		}
		br.close();
		
		return null;
	}
	*/
	
	//機器のホスト名を取得
	public static String getHostname(File curFile) throws Exception{
		BufferedReader br = new BufferedReader(new FileReader(curFile));
		String line=null;
		String mode="START";
		while ((line = br.readLine()) != null) {
			//System.out.println(line);
			if(line.matches("hostname .*")){
				br.close();
				return line.replace("hostname ","");
			}else if(line.equals("/c/sys/ssnmp")){
				mode="LB_HOSTNAME";
			}else if(mode.equals("LB_HOSTNAME") && line.matches("\tname .*")){
				String hostname=line.replaceAll("\tname","");
				hostname=hostname.replaceAll("\"","");
				br.close();
				return hostname;
			}else if(line.matches("set system host-name .*")){
				br.close();
				return line.replace("set system host-name ","");
			}
		}
		br.close();
		
		return null;
	}
}