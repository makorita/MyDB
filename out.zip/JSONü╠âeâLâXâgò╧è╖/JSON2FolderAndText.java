import java.io.*;
import java.util.*;
import java.nio.file.*;

import org.json.JSONObject;

public class JSON2FolderAndText{
/*
javac -cp "./;./json-20230618.jar" JSON2FolderAndText.java
java -cp "./;./json-20230618.jar" JSON2FolderAndText
*/
	public static void main(String[] args) throws Exception{
		//パラメータ
		String srcPath="E:/document/ナレッジ.json";
		LinkedList<String> jsonPath=new LinkedList<String>();
		jsonPath.add("ナレッジ");
		//jsonPath.add("プログラミング");
		
		
		
		// テキストを取得
		Path file = Paths.get(srcPath);
		String text = Files.readString(file);
		// JSONオブジェクトのインスタンス作成
		JSONObject curJsonObj = new JSONObject(text);
		
		//Jsonパスをたどる
		for(String curStr:jsonPath){
			//System.out.println(curStr);
			if(!curJsonObj.has(curStr)){
				System.out.println("キーが存在しません："+curStr);
				if(true)System.exit(0);
			}
			
			Object curObj=curJsonObj.get(curStr);
			if(!(curObj instanceof JSONObject)){
				System.out.println("JsonObjectではありません："+curStr);
				if(true)System.exit(0);
			}
			
			curJsonObj=(JSONObject)curObj;
		}
		
		String curPath="./"+jsonPath.get(jsonPath.size()-1)+"/";	//JSONObject自体には名前(キー)は無いのでrootの名前を予め取得
		recursiveOutput(curJsonObj,curPath);
	}
	
	static void recursiveOutput(JSONObject curJsonObj,String curPath) throws Exception{
		//System.out.println(curPath);
		File curDir=new File(curPath);
		if(curDir.exists())deleteFilesRecursively(curDir);
		curDir.mkdir();
		
		Iterator<String> it=curJsonObj.keys();
		while(it.hasNext()){
			String key=it.next();
			Object value = curJsonObj.get(key);
			if (value instanceof String) {
				//keyの文字整形
				key=getKeyStr(key);
				
				PrintWriter wr=new PrintWriter(new FileWriter(curPath+key+".txt"));
				String textStr=(String)value;
				wr.println(textStr);
				wr.close();
				
			} else if (value instanceof JSONObject) {
				JSONObject childObj=curJsonObj.getJSONObject(key);
				//keyの文字整形
				key=getKeyStr(key);
				String childPath=curPath+key+"/";
				recursiveOutput(childObj,childPath);
			}
			
		}
		
	}
	
	static boolean deleteFilesRecursively(File rootFile) {
		File[] allFiles = rootFile.listFiles();
		if (allFiles != null) {
			for (File file : allFiles) {
				deleteFilesRecursively(file);
			}
		}
		//System.out.println("Remove file: " + rootFile.getPath());
		return rootFile.delete();
	}
	
	static String getKeyStr(String inputKey){
		inputKey=inputKey.replaceAll(" ","_");
		inputKey=inputKey.replaceAll("<","＜");
		inputKey=inputKey.replaceAll(">","＞");
		inputKey=inputKey.replaceAll("\t","_");
		inputKey=inputKey.replaceAll("\\?","");
		
		return inputKey;
	}
}
