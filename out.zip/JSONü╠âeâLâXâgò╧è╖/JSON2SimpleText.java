import java.io.*;
import java.util.*;
import java.nio.file.*;

import org.json.JSONObject;
import org.json.JSONException;

public class JSON2SimpleText{
/*
javac -cp "./;./json-20230618.jar" JSON2SimpleText.java
java -cp "./;./json-20230618.jar" JSON2SimpleText
*/
	static PrintWriter wr;
	
	public static void main(String[] args) throws Exception{
		//パラメータ
		String srcPath="E:/document/ナレッジ.json";
		LinkedList<String> jsonPath=new LinkedList<String>();
		jsonPath.add("エンタメToDo");
		
		
		
		// テキストを取得
		Path file = Paths.get(srcPath);
		String text = Files.readString(file);
		// JSONオブジェクトのインスタンス作成
		JSONObject curJsonObj = new JSONObject(text);
		
		//Jsonパスをたどる
		for(String curStr:jsonPath){
			//System.out.println(curStr);
			if(!curJsonObj.has(curStr)){
				System.out.println("キーが存在しません："+curStr);
				if(true)System.exit(0);
			}
			
			Object curObj=curJsonObj.get(curStr);
			if(!(curObj instanceof JSONObject)){
				System.out.println("JsonObjectではありません："+curStr);
				if(true)System.exit(0);
			}
			
			curJsonObj=(JSONObject)curObj;
		}
		
		wr=new PrintWriter(new FileWriter(jsonPath.get(jsonPath.size()-1)+".txt"));
		recursiveWrite(curJsonObj,1);
		wr.close();
	}
	
	public static void recursiveWrite(JSONObject curObj,int level) throws Exception{
		Iterator<String> it=curObj.keys();
		while(it.hasNext()){
			String key=it.next();
			//System.out.println(key);
			if(level==1)wr.println("□"+level+" "+key);
			else{
				//String header="\t";
				//for(int i=2;i<level;i++)header+="\t";
				wr.println("□"+level+" "+key);
			}
			try{
				JSONObject curChild=curObj.getJSONObject(key);
				recursiveWrite(curChild,level+1);
				
			}catch(JSONException e){
				String curStr=curObj.getString(key);
				//System.out.println(curStr);
				wr.println(curStr);
			}
		}
	}
}
