import java.io.*;
import java.util.*;

import org.json.JSONObject;

public class Jikkou01_KnowledgeSeiri{
//javac -cp "./;./json-20230618.jar" Jikkou01_KnowledgeSeiri.java
//java -cp "./;./json-20230618.jar" Jikkou01_KnowledgeSeiri

	public static void main(String[] args) throws Exception{
		PrintWriter wr=new PrintWriter(new FileWriter("output.txt"));
		//BufferedReader br = new BufferedReader(new FileReader("E:/document/ID・アカウント.txt"));
		BufferedReader br = new BufferedReader(new FileReader("E:/document/コンピュータ/アプリケーション/Word.txt"));
		//BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(filePath), "EUC-JP"));
		String line;
		JSONObject rootObj=new JSONObject();
		JSONObject curParent=null;
		String keyStr=null;
		String valueStr=null;
		boolean mode=false;
		while ((line = br.readLine()) != null) {
			//System.out.println(line);
			//if(line.equals("◇生活"))mode=true;;
			//if(!mode)continue;
			
			if(line.matches("◆.*")){
				curParent=new JSONObject();
				rootObj.put(line.replace("◆",""),curParent);
			}
			else if(line.matches("・.*")){
				if(valueStr!=null){
					curParent.put(keyStr,valueStr);
					valueStr=null;
				}
				
				keyStr=line.replace("・","");
			}
			else if(line.length()==0)continue;
			else{
				if(valueStr==null)valueStr=line;
				else valueStr+="\r\n"+line;
			}
		}
		if(valueStr!=null){
			curParent.put(keyStr,valueStr);
			valueStr=null;
		}
		br.close();
		
		System.out.println(rootObj.toString(3));
		wr.println(rootObj.toString(3));
		wr.close();
	}
}
