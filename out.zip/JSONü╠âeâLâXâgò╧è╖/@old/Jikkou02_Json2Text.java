import java.io.*;
import java.util.*;
import java.nio.file.*;

import org.json.JSONObject;
import org.json.JSONException;

public class Jikkou02_Json2Text{
//javac -cp "./;./json-20230618.jar" Jikkou02_Json2Text.java
//java -cp "./;./json-20230618.jar" Jikkou02_Json2Text
	static PrintWriter wr;
	
	public static void main(String[] args) throws Exception{
		wr=new PrintWriter(new FileWriter("output.txt"));
		
		Path file = Paths.get("E:/document/ナレッジ.json");
		String text = Files.readString(file);
		// JSONオブジェクトのインスタンス作成
		JSONObject jsonObj = new JSONObject(text);
		recursiveWrite(jsonObj,1);
		
		wr.close();
	}
	
	public static void recursiveWrite(JSONObject curObj,int level) throws Exception{
		Iterator<String> it=curObj.keys();
		while(it.hasNext()){
			String key=it.next();
			//System.out.println(key);
			if(level==1)wr.println("□"+level+" "+key);
			else{
				String header="\t";
				for(int i=2;i<level;i++)header+="\t";
				wr.println(header+"□"+level+" "+key);
			}
			try{
				JSONObject curChild=curObj.getJSONObject(key);
				recursiveWrite(curChild,level+1);
				
			}catch(JSONException e){
				String curStr=curObj.getString(key);
				//System.out.println(curStr);
				wr.println(curStr);
			}
		}
	}
}
