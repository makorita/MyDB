import java.io.*;
import java.util.*;
import java.util.regex.*;

public class Jikkou02_MakeNAT{
	static String headerStr="ホスト名,rawConfig,in_out,変換元IP,変換先IP,オプション1,オプション2";
	
	public static void main(String[] args) throws Exception{
		//コンフィグリストの取得
		File rootDir=new File("../02_rawConfig");
		File[] configList=rootDir.listFiles();
		
		for(File curFile:configList){	//ファイル回し
			System.out.println(curFile.getName());	//処理ファイル名
			
			//ホスト名取得
			String hostname=getHostname(curFile);
			if(hostname==null || hostname.length()==0){
				System.out.println("hostname NULL:"+curFile.getName());
				System.exit(0);
			}
			
			BufferedReader br = new BufferedReader(new FileReader(curFile));
			LinkedList<String> outputList=new LinkedList<String>();
			String line;
			String nat_regex="ip nat (inside|outside) source( static)* (\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}|list .*?) (\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}|pool .*|interface .*? overload)( redundancy .*)*( add-route)*";
			Pattern p = Pattern.compile(nat_regex);
			while ((line = br.readLine()) != null) {
				//System.out.println(line);
				if(line.matches("ip nat pool .*")){
					String outputStr=hostname+","+line+",,,,,";
					outputList.add(outputStr);
					continue;
				}
				
				if(!line.matches("ip nat .*"))continue;
				
				//出力文字列生成
				Matcher m= p.matcher(line);
				if(!m.find()){
					System.out.println("想定外のNATコンフィグ:"+line);
					System.exit(0);
				}
				String outputStr=null;
				outputStr=hostname;
				outputStr+=","+line;
				outputStr+=","+m.group(1);
				outputStr+=","+m.group(3);
				outputStr+=","+m.group(4);
				if(m.group(5)==null)outputStr+=",";
				else outputStr+=","+m.group(5).replace(" ","");
				if(m.group(6)==null)outputStr+=",";
				else outputStr+=","+m.group(6).replace(" ","");
				outputList.add(outputStr);
			}
			br.close();
			
			//設定が無いときは出力しない
			if(outputList.size()==0)continue;
			
			PrintWriter wr = new PrintWriter(new BufferedWriter(new OutputStreamWriter(new FileOutputStream("../10_nat/"+hostname+"_NAT.csv"),"Shift-JIS")));
			wr.println(headerStr);
			for(String curStr:outputList){
				wr.println(curStr);
			}
			wr.close();
		}
	}
	
	//機器のホスト名を取得
	public static String getHostname(File curFile) throws Exception{
		BufferedReader br = new BufferedReader(new FileReader(curFile));
		String line=null;
		String mode="START";
		while ((line = br.readLine()) != null) {
			//System.out.println(line);
			if(line.matches("hostname .*")){
				br.close();
				return line.replace("hostname ","");
			}else if(line.equals("/c/sys/ssnmp")){
				mode="LB_HOSTNAME";
			}else if(mode.equals("LB_HOSTNAME") && line.matches("\tname .*")){
				String hostname=line.replaceAll("\tname","");
				hostname=hostname.replaceAll("\"","");
				br.close();
				return hostname;
			}else if(line.matches("set system host-name .*")){
				br.close();
				return line.replace("set system host-name ","");
			}
		}
		br.close();
		
		return null;
	}
}