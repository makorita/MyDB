import java.io.*;
import java.util.*;
import java.util.regex.*;

public class Jikkou02_MakeIfAccessList{
	static String headerStr="ホスト名,rawConfig,シーケンス番号,acl番号,許可_拒否,プロトコル,送信元IP,送信元ワイルドカード,送信元オプション,宛先IP,宛先ワイルドカード,宛先オプション,remark文字列";
	
	public static void main(String[] args) throws Exception{
		//コンフィグリストの取得
		File rootDir=new File("../02_rawConfig");
		File[] configList=rootDir.listFiles();
		
		for(File curFile:configList){	//ファイル回し
			System.out.println(curFile.getName());	//処理ファイル名
			
			//ホスト名取得
			String hostname=getHostname(curFile);
			
			//access-list番号取得
			String inAclNum=getInAclNum(curFile);
			if(inAclNum==null)continue;
			String outAclNum=getOutAclNum(curFile);
			if(outAclNum==null)continue;
			
			String acl_regex="access-list( \\d+)( permit| deny *)( tcp| udp| icmp| ip)( host \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}| \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3} \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}| any)(.*?)( host \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}| \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3} \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}| any)(.*)";
			Pattern p = Pattern.compile(acl_regex);
			
			BufferedReader br = new BufferedReader(new FileReader(curFile));
			LinkedList<String> outputList=new LinkedList<String>();
			String remarkStr=null;
			String aclNum=null;
			int seqNum=10;
			String line;
			while ((line = br.readLine()) != null) {
				//System.out.println(line);
				if(!line.matches("access-list ("+inAclNum+"|"+outAclNum+") .*"))continue;
				
				//ACL番号取得
				String[] word1=line.split(" ");
				if(aclNum==null)aclNum=word1[1];
				else if(!aclNum.equals(word1[1])){
					aclNum=word1[1];
					seqNum=10;
				}
				
				//出力文字列生成
				String outputStr=null;
				outputStr=hostname;
				outputStr+=","+line;
				if(line.matches(".*remark .*")){
					String tmpStr=line.replaceAll("access-list ","");
					tmpStr=tmpStr.replaceAll(" remark.*","");
					remarkStr=line.replaceAll(".*remark ","");
					outputStr+=",,"+tmpStr+",remark"+",,,,,,,,"+remarkStr;
					outputList.add(outputStr);
					continue;
				}
				
				Matcher m = p.matcher(line);
				if(!m.find()){
					System.out.println("想定外のaccess-list:"+line);
					System.exit(0);
				}
				
				outputStr+=","+seqNum;
				seqNum+=10;
				outputStr+=","+m.group(1).replaceAll(" ","");
				outputStr+=","+m.group(2).replaceAll(" ","");
				outputStr+=","+m.group(3).replaceAll(" ","");
				String[] word=m.group(4).split(" ");
				if(word[1].equals("host")){
					outputStr+=","+word[2]+",0.0.0.0";
				}else if(word[1].equals("any")){
					outputStr+=",0.0.0.0,255.255.255.255";
				}else{
					outputStr+=","+word[1]+","+word[2];
				}
				outputStr+=","+m.group(5);
				word=m.group(6).split(" ");
				if(word[1].equals("host")){
					outputStr+=","+word[2]+",0.0.0.0";
				}else if(word[1].equals("any")){
					outputStr+=",0.0.0.0,255.255.255.255";
				}else{
					outputStr+=","+word[1]+","+word[2];
				}
				outputStr+=","+m.group(7);
				outputStr+=","+remarkStr;
				outputList.add(outputStr);
			}
			br.close();
			
			//設定が無いときは出力しない
			if(outputList.size()==0)continue;
			
			PrintWriter wr = new PrintWriter(new BufferedWriter(new OutputStreamWriter(new FileOutputStream("../10_acl/"+hostname+"_ACL.csv"),"Shift-JIS")));
			wr.println(headerStr);
			for(String curStr:outputList){
				wr.println(curStr);
			}
			wr.close();
		}
	}
	
	//in方向のaccess-list番号取得
	public static String getInAclNum(File curFile) throws Exception{
		BufferedReader br = new BufferedReader(new FileReader(curFile));
		
		String line;
		while ((line = br.readLine()) != null) {
			//System.out.println(line);
			if(line.matches(" ip access-group \\d+ in")){
				String returnStr=line;
				returnStr=returnStr.replace(" ip access-group ","");
				returnStr=returnStr.replace(" in","");
				return returnStr;
			}
		}
		br.close();
		
		return null;
	}
	
	//out方向のaccess-list番号取得
	public static String getOutAclNum(File curFile) throws Exception{
		BufferedReader br = new BufferedReader(new FileReader(curFile));
		
		String line;
		while ((line = br.readLine()) != null) {
			//System.out.println(line);
			if(line.matches(" ip access-group \\d+ out")){
				String returnStr=line;
				returnStr=returnStr.replace(" ip access-group ","");
				returnStr=returnStr.replace(" out","");
				return returnStr;
			}
		}
		br.close();
		
		return null;
	}
	
	//機器のホスト名を取得
	public static String getHostname(File curFile) throws Exception{
		BufferedReader br = new BufferedReader(new FileReader(curFile));
		String line=null;
		String mode="START";
		while ((line = br.readLine()) != null) {
			//System.out.println(line);
			if(line.matches("hostname .*")){
				br.close();
				return line.replace("hostname ","");
			}else if(line.equals("/c/sys/ssnmp")){
				mode="LB_HOSTNAME";
			}else if(mode.equals("LB_HOSTNAME") && line.matches("\tname .*")){
				String hostname=line.replaceAll("\tname","");
				hostname=hostname.replaceAll("\"","");
				br.close();
				return hostname;
			}else if(line.matches("set system host-name .*")){
				br.close();
				return line.replace("set system host-name ","");
			}
		}
		br.close();
		
		return null;
	}
}