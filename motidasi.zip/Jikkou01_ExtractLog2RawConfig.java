import java.io.*;
import java.util.*;

public class Jikkou01_ExtractLog2RawConfig{
	/*
	ログファイルのstart文字列からend文字列までのログを別テキストに出力
	*/
	static LinkedList<File> configList;
	public static void main(String[] args) throws Exception{
		//コンフィグリストの取得
		configList=new LinkedList<File>();
		File rootDir=new File("../01_input");
		recursiveCheck(rootDir);
		
		//ファイル回し
		for(File curFile:configList){
			//処理中のファイル名
			System.out.println(curFile.getName());
			
			String hostname=getHostname(curFile);
			if(hostname==null|hostname.length()==0){
				System.out.println("hostname Null:"+curFile.getName());
				System.exit(0);
			}
			
			//抽出ログ出力開始
			PrintWriter wr=new PrintWriter(new FileWriter("../02_rawConfig/"+hostname+"_rawConfig.txt"));
			BufferedReader br = new BufferedReader(new FileReader(curFile));
			String line;
			String mode="START";
			while ((line = br.readLine()) != null) {
				//System.out.println(line);
				
				if(mode.equals("START")){	//開始条件
					if(line.matches(".*sho.* conf.*") || line.matches(".*sho.* run.*") || line.matches(".*sho.* sta.*") || line.matches("Current configuration :.*") || line.equals(": Saved") || line.matches("script start .*"))mode="RUN";
				}else if(mode.equals("RUN")){	//終了条件
					if(line.equals("end") || line.equals(": end") || line.equals("Cryptochecksum:.*") || line.matches("script end .*") || line.matches(".*EJ.*>.*")){
						wr.println(line);
						mode="END";
						break;
					}
				}
				
				if(mode.equals("RUN"))wr.println(line);
			}
			br.close();
			wr.close();
			
			//エラーチェック
			if(!mode.equals("END")){
				System.out.println("not END:"+mode+" :"+curFile.getName());
				System.exit(0);
			}
		}
	}
	
	//機器のホスト名を取得
	public static String getHostname(File curFile) throws Exception{
		BufferedReader br = new BufferedReader(new FileReader(curFile));
		String line=null;
		String mode="START";
		while ((line = br.readLine()) != null) {
			//System.out.println(line);
			if(line.matches("hostname .*")){
				br.close();
				return line.replace("hostname ","");
			}else if(line.equals("/c/sys/ssnmp")){
				mode="LB_HOSTNAME";
			}else if(mode.equals("LB_HOSTNAME") && line.matches("\tname .*")){
				String hostname=line.replaceAll("\tname","");
				hostname=hostname.replaceAll("\"","");
				br.close();
				return hostname;
			}else if(line.matches("set system host-name .*")){
				br.close();
				return line.replace("set system host-name ","");
			}
		}
		br.close();
		
		return null;
	}
	
	//フォルダ内のファイルを再帰検索
	public static void recursiveCheck(File curDir){
		if(curDir.getName().matches(".*old.*"))return;
		
		File[] childList=curDir.listFiles();
		for(File curFile:childList){
			if(curFile.isDirectory())recursiveCheck(curFile);
			else if(curFile.isFile()){
				if(curFile.getName().matches(".*\\.lnk"))continue;
				if(curFile.getName().matches(".*\\.xls.*"))continue;
				if(curFile.getName().matches(".*\\.ppt.*"))continue;
				if(curFile.getName().matches(".*\\.zip"))continue;
				if(curFile.getName().matches(".*\\.db"))continue;
				
				configList.add(curFile);
			}
		}
	}
}
