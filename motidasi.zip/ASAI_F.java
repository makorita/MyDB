import java.io.*;
import java.util.*;

public class ASAI_F{
	//メジャーな要素だけメンバーに組み込む
	String ifName;
	String description;
	String ip;
	String mask;
	String standby;
	boolean shutdown;
	String speed;
	String duplex;
	String securityLevel;
	String nameif;
	String vlan;
	public I_F(){
		shutdown=false;
	}
	
	public String getIfName(){
		return ifName;
	}
	
	public void setIfName(String ifName){
		this.ifName=ifName;
	}
	
	public boolean isShutdown(){
		return shutdown;
	}
	
	public void setShutdown(boolean shutdown){
		this.shutdown=shutdown;
	}
	
	public String getDescription(){
		return description;
	}
	
	public void setDescription(String description){
		this.description=description;
	}
	
	public String getIP(){
		return ip;
	}
	
	public void setIP(String ip){
		this.ip=ip;
	}
	
	public String getMask(){
		return mask;
	}
	
	public void setMask(String mask){
		this.mask=mask;
	}
	
	public String getStandby(){
		return standby;
	}
	
	public void setStandby(String standby){
		this.standby=standby;
	}
	
	public String getSpeed(){
		return speed;
	}
	
	public void setSpeed(String speed){
		this.speed=speed;
	}
	
	public String getDuplex(){
		return duplex;
	}
	
	public void setDuplex(String duplex){
		this.duplex=duplex;
	}
	
	public String getSecurityLevel(){
		return securityLevel;
	}
	
	public void setSecurityLevel(String securityLevel){
		this.securityLevel=securityLevel;
	}
	
	public String getNameif(){
		return nameif;
	}
	
	public void setNameif(String nameif){
		this.nameif=nameif;
	}
	
	public String getVlan(){
		return vlan;
	}
	
	public void setVlan(String vlan){
		this.vlan=vlan;
	}
	
	public String getOutputStr(){
		String outputStr=null;
		
		outputStr=ifName;
		outputStr+=",";
		outputStr+=shutdown;
		outputStr+=",";
		if(description!=null)outputStr+=description;
		outputStr+=",";
		if(speed!=null)outputStr+=speed;
		outputStr+=",";
		if(duplex!=null)outputStr+=duplex;
		outputStr+=",";
		if(ip!=null)outputStr+=ip;
		outputStr+=",";
		if(mask!=null)outputStr+=mask;
		outputStr+=",";
		if(standby!=null)outputStr+=standby;
		outputStr+=",";
		if(securityLevel!=null)outputStr+=securityLevel;
		outputStr+=",";
		if(nameif!=null)outputStr+=nameif;
		outputStr+=",";
		if(vlan!=null)outputStr+=vlan;
		
		return outputStr;
	}
}
