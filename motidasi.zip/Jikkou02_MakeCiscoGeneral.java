import java.io.*;
import java.util.*;
import java.util.regex.*;

public class Jikkou02_MakeCiscoGeneral{
	static String headerStr="ホスト名,IOS Version";
	static LinkedList<File> configList;
	public static void main(String[] args) throws Exception{
		//コンフィグリストの取得
		configList=new LinkedList<File>();
		File rootDir=new File("../01_input");
		recursiveCheck(rootDir);
		
		PrintWriter wr = new PrintWriter(new BufferedWriter(new OutputStreamWriter(new FileOutputStream("../10_general/Cisco_General.csv"),"Shift-JIS")));
		wr.println(headerStr);
		for(File curFile:configList){	//ファイル回し
			System.out.println(curFile.getName());	//処理ファイル名
			
			//ホスト名取得
			String hostname=getHostname(curFile);
			if(hostname==null)continue;
			
			BufferedReader br = new BufferedReader(new FileReader(curFile));
			HashMap<String,String> paraMap=new HashMap<String,String>();
			String line;
			while ((line = br.readLine()) != null) {
				//System.out.println(line);
				if(line.matches(".*Software.* Version .*")){
					//System.out.println(line);
					String[] word=line.split(" |,");
					for(int i=0;i<word.length;i++){
						if(word[i].equals("Version")){
							//System.out.println(word[i+1]);
							if(!paraMap.containsKey("ios"))paraMap.put("ios",word[i+1]);
						}
					}
				}
			}
			br.close();
			
			String outputStr=hostname;
			outputStr+=",";
			if(paraMap.containsKey("ios"))outputStr+=paraMap.get("ios");
			
			wr.println(outputStr);
		}
		wr.close();
	}
	
	//機器のホスト名を取得
	public static String getHostname(File curFile) throws Exception{
		BufferedReader br = new BufferedReader(new FileReader(curFile));
		String line=null;
		LinkedList<String> rowList=new LinkedList<String>();
		while ((line = br.readLine()) != null) {
			rowList.add(line);
		}
		br.close();
		
		//sh runから取得
		for(String curStr:rowList){
			if(curStr.matches("hostname .*")){
				return curStr.replace("hostname ","");
			}
		}
		
		//プロンプトから取得
		for(String curStr:rowList){
			if(curStr.matches(".*#sh.*")){
				String[] word=curStr.split("#");
				return word[0];
			}
		}
		
		return null;
	}
	
	//フォルダ内のファイルを再帰検索
	public static void recursiveCheck(File curDir){
		if(curDir.getName().matches(".*old.*"))return;
		
		File[] childList=curDir.listFiles();
		for(File curFile:childList){
			if(curFile.isDirectory())recursiveCheck(curFile);
			else if(curFile.isFile()){
				if(curFile.getName().matches(".*\\.lnk"))continue;
				if(curFile.getName().matches(".*\\.xls.*"))continue;
				if(curFile.getName().matches(".*\\.ppt.*"))continue;
				if(curFile.getName().matches(".*\\.zip"))continue;
				if(curFile.getName().matches(".*\\.db"))continue;
				
				configList.add(curFile);
			}
		}
	}
}