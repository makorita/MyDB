import java.io.*;
import java.util.*;

public class GroupRow{
	static final String blankStr="#BLANK#";
	static final String sepalateStr="#SEP#";
	static final String kaigyouStr="#KAI#";
	
	ArrayList<ArrayList<String>> cellList;
	public GroupRow(){
		cellList=new ArrayList<ArrayList<String>>();
	}
	
	public String getStr(int colIndex,int wordIndex){
		return cellList.get(colIndex).get(wordIndex);
	}
	
	public void addStr(int index,String addStr){
		if(addStr.length()==0)addStr=blankStr;
		
		if(index>=cellList.size()){
			for(int i=cellList.size();i<=index;i++){
				cellList.add(new ArrayList<String>());
			}
		}
		cellList.get(index).add(addStr);
	}
	
	public String getJogaiStr(int jogaiColNum){
		String returnStr=null;
		for(int i=0;i<cellList.size();i++){
			if(i==jogaiColNum)continue;
			
			if(returnStr!=null)returnStr+=sepalateStr;
			for(String curStr:cellList.get(i)){
				if(returnStr==null)returnStr=curStr;
				else returnStr+=kaigyouStr+curStr;
			}
		}
		
		return returnStr;
	}
	
	public int size(){
		return cellList.size();
	}
	
	public int size(int index){
		return cellList.get(index).size();
	}
	
	public boolean contains(String checkRegex,int index){
		for(String curStr:cellList.get(index)){
			if(curStr.matches(checkRegex))return true;
		}
		
		return false;
	}
	
	public void removeDuplicate(int dupColNum){
		ArrayList<String> curList=cellList.get(dupColNum);
		cellList.set(dupColNum,new ArrayList<String>(new HashSet<String>(curList)));
	}
	
	public void sort(int sortColNum){
		ArrayList<String> curList=cellList.get(sortColNum);
		//Collections.sort(curList,Collections.reverseOrder());
		Collections.sort(curList);
	}
	
	public void showAll(){
		for(ArrayList<String> curList:cellList){
			for(String curStr:curList){
				System.out.print(curStr+",");
			}
			System.out.print("\t");
		}
		System.out.println();
	}
}
