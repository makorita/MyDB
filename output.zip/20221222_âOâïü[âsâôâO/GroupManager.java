import java.io.*;
import java.util.*;

import org.apache.poi.*;
import org.apache.poi.ss.formula.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.openxml4j.exceptions.*;
import org.apache.poi.xssf.usermodel.*;

public class GroupManager{
	ArrayList<GroupRow> groupRowList;
	public GroupManager(){
		groupRowList=new ArrayList<GroupRow>();
	}
	
	public void loadExcel(String srcPath,String sheetName) throws Exception{
		Workbook wb = WorkbookFactory.create(new FileInputStream(srcPath));
		Sheet sheet=wb.getSheet(sheetName);
		Row topRow=sheet.getRow(0);
		int maxColNum=topRow.getLastCellNum();
		for(int rowIndex=0;rowIndex<=sheet.getLastRowNum();rowIndex++){	//rowの最大値は最大index
			Row row=sheet.getRow(rowIndex);
			if(row==null)continue;
			
			GroupRow curGrpRow=new GroupRow();
			groupRowList.add(curGrpRow);
			for(int cellIndex=0;cellIndex<maxColNum;cellIndex++){
				Cell cell=row.getCell(cellIndex);
				if(cell==null)curGrpRow.addStr(cellIndex,"");
				else if(cell.getCellType()==CellType.STRING){
					String tmpStr=cell.getStringCellValue();
					String[] word=tmpStr.split("\n");
					for(String curStr:word){
						curGrpRow.addStr(cellIndex,curStr);
					}
				}else if(cell.getCellType()==CellType.NUMERIC)curGrpRow.addStr(cellIndex,String.valueOf((int)cell.getNumericCellValue()));
				else if(cell.getCellType()==CellType.BLANK)curGrpRow.addStr(cellIndex,"");
				else if(cell.getCellType()==CellType.BOOLEAN){
					if(cell.getBooleanCellValue())curGrpRow.addStr(cellIndex,"true");
					else curGrpRow.addStr(cellIndex,"false");
				}else{
					System.out.println("想定外のセルタイプ:"+cell.getCellType());
					System.exit(0);
				}
			}
		}
		
		wb.close();
	}
	
	public void saveExcel(String dstPath,String sheetName) throws Exception{
		Workbook wb = WorkbookFactory.create(new FileInputStream(dstPath));
		Sheet sheet=wb.getSheet(sheetName);
		if(sheet!=null){
			wb.removeSheetAt(wb.getSheetIndex(sheetName));
		}
		sheet=wb.createSheet(sheetName);
		
		for(int i=0;i<groupRowList.size();i++){
			GroupRow curGrpRow=groupRowList.get(i);
			
			Row row=sheet.getRow(i);
			if(row==null)row=sheet.createRow(i);
			for(int j=0;j<curGrpRow.size();j++){
				Cell cell=row.getCell(j);
				if(cell==null)cell=row.createCell(j);
				String outputStr=null;
				for(int k=0;k<curGrpRow.size(j);k++){
					if(outputStr==null)outputStr=curGrpRow.getStr(j,k);
					else outputStr+="\n"+curGrpRow.getStr(j,k);
				}
				cell.setCellValue(outputStr);
			}
		}

		FileOutputStream out = new FileOutputStream(dstPath);
		
		wb.write(out);
		
		out.close();
		
		wb.close();
	}
	
	public void mergeRow(int mergeColNum){
		HashMap<String,GroupRow> kisyutuMap=new HashMap<String,GroupRow>();
		for(GroupRow curGrpRow:groupRowList){
			String jogaiStr=curGrpRow.getJogaiStr(mergeColNum);
			if(kisyutuMap.containsKey(jogaiStr)){
				GroupRow masterRow=kisyutuMap.get(jogaiStr);
				if(legalCheck(curGrpRow,masterRow,mergeColNum)){
					for(int i=0;i<curGrpRow.size(mergeColNum);i++){
						masterRow.addStr(mergeColNum,curGrpRow.getStr(mergeColNum,i));
					}
				}else{
					kisyutuMap.put(jogaiStr,curGrpRow);
				}
			}else{
				kisyutuMap.put(jogaiStr,curGrpRow);
			}
		}
		
		groupRowList=new ArrayList<GroupRow>();
		for(GroupRow curGrpRow : kisyutuMap.values()){
			//重複行削除
			curGrpRow.removeDuplicate(mergeColNum);
			//ソート実行
			curGrpRow.sort(mergeColNum);
			
			groupRowList.add(curGrpRow);
		}
	}
	
	//★★★ここで詳細な条件を設定する★★★
	public boolean legalCheck(GroupRow checkRow,GroupRow masterRow,int index){
		/*
		if(index==4){
			if(checkRow.contains("172\\.(16|17|18|19|20|21|22|23|24|25|26|27|28|29|30|31)\\..*",6) || checkRow.contains("10\\.(16|17|20|21|24|25|28|29)\\..*",6)){
				if(!checkRow.contains("(172|10)\\.\\d{2}\\.(4|13)\\..*",6)){
					return false;
				}
			}
			
			if(masterRow.contains("172\\.(16|17|18|19|20|21|22|23|24|25|26|27|28|29|30|31)\\..*",6) || masterRow.contains("10\\.(16|17|20|21|24|25|28|29)\\..*",6)){
				if(!masterRow.contains("(172|10)\\.\\d{2}\\.(4|13)\\..*",6)){
					return false;
				}
			}
		}else if(index==6){
			if(checkRow.contains("172\\.(16|17|18|19|20|21|22|23|24|25|26|27|28|29|30|31)\\..*",4) || checkRow.contains("10\\.(16|17|20|21|24|25|28|29)\\..*",4)){
				if(!checkRow.contains("(172|10)\\.\\d{2}\\.(4|13)\\..*",4)){
					return false;
				}
			}
			
			if(masterRow.contains("172\\.(16|17|18|19|20|21|22|23|24|25|26|27|28|29|30|31)\\..*",4) || masterRow.contains("10\\.(16|17|20|21|24|25|28|29)\\..*",4)){
				if(!masterRow.contains("(172|10)\\.\\d{2}\\.(4|13)\\..*",4)){
					return false;
				}
			}
		}
		*/
		
		return true;
	}
	
	public void showAll(){
		for(GroupRow curGrpRow:groupRowList){
			curGrpRow.showAll();
		}
	}
}
