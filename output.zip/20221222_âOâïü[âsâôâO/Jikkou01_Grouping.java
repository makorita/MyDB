import java.io.*;
import java.util.*;

public class Jikkou01_Grouping{
	static LinkedList<File> configList;
	public static void main(String[] args) throws Exception{
		GroupManager gm=new GroupManager();
//		gm.loadExcel("コンフィグ読み込みテスト.xlsx","通信要件列抽出");
//		gm.mergeRow(3);
//		gm.saveExcel("コンフィグ読み込みテスト.xlsx","protocolマージ");
		
//		gm.loadExcel("コンフィグ読み込みテスト.xlsx","protocolマージ");
//		gm.mergeRow(4);
//		gm.mergeRow(6);
//		gm.saveExcel("コンフィグ読み込みテスト.xlsx","個社Netマージ");
		
		//legal check変更
		gm.loadExcel("コンフィグ読み込みテスト.xlsx","個社Netマージ");
		gm.mergeRow(4);
		gm.mergeRow(6);
		gm.mergeRow(7);
		gm.saveExcel("コンフィグ読み込みテスト.xlsx","全マージ");
	}
}
