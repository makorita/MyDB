import java.io.*;
import java.util.*;
import java.util.regex.*;

public class Jikkou03_MakeASARouting{
	static String headerStr="ホスト名,rawConfig,nameif,宛先NW,宛先マスク,NextHop";
	
	public static void main(String[] args) throws Exception{
		//コンフィグリストの取得
		File rootDir=new File("../02_rawConfig");
		File[] configList=rootDir.listFiles();
		
		for(File curFile:configList){	//ファイル回し
			if(!curFile.getName().matches(".*FW.*"))continue;
			System.out.println(curFile.getName());	//処理ファイル名
			
			//ホスト名取得
			String hostname=getHostname(curFile);
			
			BufferedReader br = new BufferedReader(new FileReader(curFile));
			LinkedList<String> outputList=new LinkedList<String>();
			String line;
			while ((line = br.readLine()) != null) {
				//System.out.println(line);
				if(!line.matches("route .* \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3} \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3} \\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3} 1"))continue;
				
				//出力文字列生成
				String[] word=line.split(" ");
				String outputStr=null;
				outputStr=hostname;
				outputStr+=","+line;
				outputStr+=","+word[1];
				outputStr+=","+word[2];
				outputStr+=","+word[3];
				outputStr+=","+word[4];
				outputList.add(outputStr);
			}
			br.close();
			
			//設定が無いときは出力しない
			if(outputList.size()==0)continue;
			
			PrintWriter wr = new PrintWriter(new BufferedWriter(new OutputStreamWriter(new FileOutputStream("../11_asa_routing/"+hostname+"_ASARouting.csv"),"Shift-JIS")));
			wr.println(headerStr);
			for(String curStr:outputList){
				wr.println(curStr);
			}
			wr.close();
		}
	}
	
	//機器のホスト名を取得
	public static String getHostname(File curFile) throws Exception{
		BufferedReader br = new BufferedReader(new FileReader(curFile));
		String line=null;
		String mode="START";
		while ((line = br.readLine()) != null) {
			//System.out.println(line);
			if(line.matches("hostname .*")){
				br.close();
				return line.replace("hostname ","");
			}else if(line.equals("/c/sys/ssnmp")){
				mode="LB_HOSTNAME";
			}else if(mode.equals("LB_HOSTNAME") && line.matches("\tname .*")){
				String hostname=line.replaceAll("\tname","");
				hostname=hostname.replaceAll("\"","");
				br.close();
				return hostname;
			}else if(line.matches("set system host-name .*")){
				br.close();
				return line.replace("set system host-name ","");
			}
		}
		br.close();
		
		return null;
	}
}