import java.io.*;
import java.util.*;

public class I_F{
	//メジャーな要素だけメンバーに組み込む
	String ifName;
	String description;
	LinkedList<Address> ipList;
	boolean negotiated;
	boolean shutdown;
	String speed;
	String duplex;
	String standbyIP1;
	String standbyGroup1;
	String standbyIP2;
	String standbyGroup2;
	String accessGroupInNum;
	String accessGroupOutNum;
	String ipNatI_O;
	String accessVlan;
	String switchportMode;
	String allowedVlan;
	String channelGroup;
	String channelMode;
	public I_F(){
		ipList=new LinkedList<Address>();
		negotiated=false;
		shutdown=false;
	}
	
	public String getIfName(){
		return ifName;
	}
	
	public void setIfName(String ifName){
		this.ifName=ifName;
	}
	
	public String getIfType(){
		if(getIfName().matches("Tunnel.*"))return "Tunnel";
		else if(getIfName().matches("Embedded-Service-Engine.*"))return "Embedded-Service-Engine";
		else if(getIfName().matches("Loopback.*"))return "Loopback";
		else if(getIfName().matches("Ethernet.*"))return "Ethernet";
		else if(getIfName().matches("FastEthernet.*"))return "FastEthernet";
		else if(getIfName().matches("GigabitEthernet.*"))return "GigabitEthernet";
		else if(getIfName().matches("TenGigabitEthernet.*"))return "TenGigabitEthernet";
		else if(getIfName().matches("Async.*"))return "Async";
		else if(getIfName().matches("BRI.*"))return "BRI";
		else if(getIfName().matches("Dialer.*"))return "Dialer";
		else if(getIfName().matches("Vlan.*"))return "Vlan";
		else if(getIfName().matches("Port-channel.*"))return "Port-channel";
		else if(getIfName().matches("Management.*"))return "Management";

		return null;
	}
	
	public boolean isNegotiated(){
		return negotiated;
	}
	
	public void setNegotiated(boolean negotiated){
		this.negotiated=negotiated;
	}
	
	public boolean isShutdown(){
		return shutdown;
	}
	
	public void setShutdown(boolean shutdown){
		this.shutdown=shutdown;
	}
	
	public String getDescription(){
		return description;
	}
	
	public void setDescription(String description){
		this.description=description;
	}
	
	public String getIP(int index){
		return ipList.get(index).getSimpleStrExp();
	}
	
	public int getMaskLength(int index){
		return ipList.get(index).getMaskLength();
	}
	
	public void addIP(String ipStr,String maskStr){
		Address tmpAddr=new Address(ipStr,maskStr);
		ipList.add(0,tmpAddr);
	}
	
	public void addIPSecondary(String ipStr,String maskStr){
		Address tmpAddr=new Address(ipStr,maskStr);
		ipList.add(tmpAddr);
	}
	
	public String getStandbyIP1(){
		return standbyIP1;
	}
	
	public void setStandbyIP1(String standbyIP1){
		this.standbyIP1=standbyIP1;
	}
	
	public String getStandbyIP2(){
		return standbyIP2;
	}
	
	public void setStandbyIP2(String standbyIP2){
		this.standbyIP2=standbyIP2;
	}
	
	public String getStandbyGroup1(){
		return standbyGroup1;
	}
	
	public void setStandbyGroup1(String standbyGroup1){
		this.standbyGroup1=standbyGroup1;
	}
	
	public String getStandbyGroup2(){
		return standbyGroup2;
	}
	
	public void setStandbyGroup2(String standbyGroup2){
		this.standbyGroup2=standbyGroup2;
	}
	
	public String getAccessVlan(){
		return accessVlan;
	}
	
	public void setAccessVlan(String accessVlan){
		this.accessVlan=accessVlan;
	}
	
	public String getSwitchportMode(){
		return switchportMode;
	}
	
	public void setSwitchportMode(String switchportMode){
		this.switchportMode=switchportMode;
	}
	
	public String getAllowedVlan(){
		return allowedVlan;
	}
	
	public void addAllowedVlan(String curStr){
		if(allowedVlan==null)allowedVlan=curStr;
		else allowedVlan+="<c>"+curStr;
	}
	
	public String getSpeed(){
		return speed;
	}
	
	public void setSpeed(String speed){
		this.speed=speed;
	}
	
	public String getDuplex(){
		return duplex;
	}
	
	public void setDuplex(String duplex){
		this.duplex=duplex;
	}
	
	public String getChannelGroup(){
		return channelGroup;
	}
	
	public void setChannelGroup(String channelGroup){
		this.channelGroup=channelGroup;
	}
	
	public String getChannelMode(){
		return channelMode;
	}
	
	public void setChannelMode(String channelMode){
		this.channelMode=channelMode;
	}
	
	public String getAccessGroupInNum(){
		return accessGroupInNum;
	}
	
	public void setAccessGroupInNum(String accessGroupInNum){
		this.accessGroupInNum=accessGroupInNum;
	}
	
	public String getAccessGroupOutNum(){
		return accessGroupOutNum;
	}
	
	public void setAccessGroupOutNum(String accessGroupOutNum){
		this.accessGroupOutNum=accessGroupOutNum;
	}
	
	public String getIPNat(){
		return ipNatI_O;
	}
	
	public void setIPNat(String ipNatI_O){
		this.ipNatI_O=ipNatI_O;
	}
	
	public String getOutputStr(){
		String outputStr=null;
		
		outputStr=ifName;
		outputStr+=",";
		outputStr+=shutdown;
		outputStr+=",";
		if(description!=null)outputStr+=description;
		outputStr+=",";
		if(speed!=null)outputStr+=speed;
		outputStr+=",";
		if(duplex!=null)outputStr+=duplex;
		outputStr+=",";
		if(isNegotiated())outputStr+="negotiated";
		else if(ipList.size()>=1)outputStr+=getIP(0);
		outputStr+=",";
		if(ipList.size()>=1)outputStr+=getMaskLength(0);
		outputStr+=",";
		if(ipList.size()>=2)outputStr+=getIP(1);
		outputStr+=",";
		if(ipList.size()>=2)outputStr+=getMaskLength(1);
		outputStr+=",";
		if(ipList.size()>=3)outputStr+=getIP(2);
		outputStr+=",";
		if(ipList.size()>=3)outputStr+=getMaskLength(2);
		outputStr+=",";
		if(standbyIP1!=null)outputStr+=standbyIP1;
		outputStr+=",";
		if(standbyGroup1!=null)outputStr+=standbyGroup1;
		outputStr+=",";
		if(standbyIP2!=null)outputStr+=standbyIP2;
		outputStr+=",";
		if(standbyGroup2!=null)outputStr+=standbyGroup2;
		outputStr+=",";
		if(accessGroupInNum!=null)outputStr+=accessGroupInNum;
		outputStr+=",";
		if(accessGroupOutNum!=null)outputStr+=accessGroupOutNum;
		outputStr+=",";
		if(ipNatI_O!=null)outputStr+=ipNatI_O;
		outputStr+=",";
		if(switchportMode!=null)outputStr+=switchportMode;
		outputStr+=",";
		if(accessVlan!=null)outputStr+=accessVlan;
		outputStr+=",";
		if(allowedVlan!=null)outputStr+=allowedVlan;
		outputStr+=",";
		if(channelGroup!=null)outputStr+=channelGroup;
		outputStr+=",";
		if(channelMode!=null)outputStr+=channelMode;
		
		return outputStr;
	}
}
