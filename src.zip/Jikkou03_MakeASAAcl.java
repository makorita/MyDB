import java.io.*;
import java.util.*;
import java.util.regex.*;

public class Jikkou03_MakeASAAcl{
	static String headerStr="ホスト名,rawConfig,index,zone,action,L2protocol,L1protocol,L5SrcNet,L4SrcNet,L3SrcNet,L2SrcNet,L1SrcNet,L1SrcPort,L5DstNet,L4DstNet,L3DstNet,L2DstNet,L1DstNet,L3DstPort,L2DstPort,L1DstPort,log";
	
	public static void main(String[] args) throws Exception{
		//コンフィグリストの取得
		File rootDir=new File("../02_rawConfig");
		File[] configList=rootDir.listFiles();
		
		for(File curFile:configList){	//ファイル回し
			if(!curFile.getName().matches(".*FW.*"))continue;
			System.out.println(curFile.getName());	//処理ファイル名
			
			//ホスト名取得
			String hostname=getHostname(curFile);
			
			//object groupマップ取得
			HashMap<String,ObjectGroup> objectGroupMap=getObjectGroupMap(curFile);
			
			//levelセット。最大値|network:5,service:3,protocol:2
			int maxLevel=0;
			for(ObjectGroup curObjGrp : objectGroupMap.values()){
				//System.out.println(curObjGrp.getName());
				//curObjGrp.showListSize();
				//if(!curObjGrp.getType().equals("protocol"))continue;
				int curMaxLevel=curObjGrp.getMaxLevel(1,objectGroupMap);
				curObjGrp.setMaxLevel(curMaxLevel);	//再帰的なセットはしない。全オブジェクトグループでループさせてセットする。⇒使用しなくなった。
				//curObjGrp.showAll();
				
				/*
				if(curMaxLevel>maxLevel){
					curObjGrp.showAll();
					System.out.println(curMaxLevel);
					maxLevel=curMaxLevel;
				}
				*/
			}
			
			BufferedReader br = new BufferedReader(new FileReader(curFile));
			LinkedList<String> outputList=new LinkedList<String>();
			String line;
			HashMap<String,Integer> indexMap=new HashMap<String,Integer>();
			String regex = "access-list (.+?) extended (permit|deny) (ip|icmp|tcp|udp|object-group .+?) (any|object-group .+?)( eq .+?| range .+? .+?)* (any|object-group .+?)( eq .+?| range .+? .+?| object-group .+?)*( log)* ";	//src portにobject groupはマッチさせない。dst netかどうか判断が面倒なため。現状使われていない。
			Pattern p = Pattern.compile(regex);
			while ((line = br.readLine()) != null) {
				if(!line.matches("access-list .*"))continue;
				
				String[] word=line.split(" ");
				if(line.matches("access-list .* remark .*")){
					outputList.add(hostname+","+line+",,"+word[1]+",remark");
				}else if(line.matches(regex)){
					//indexの更新
					int curInt=0;
					if(indexMap.containsKey(word[1]))curInt=indexMap.get(word[1]);
					curInt++;
					indexMap.put(word[1],curInt);
					
					Matcher m = p.matcher(line);
					m.find();
					String curZone=m.group(1);
					String curAction=m.group(2);
					String curProto=m.group(3);
					String curSrcNet=m.group(4);
					String curSrcPort=m.group(5);
					String curDstNet=m.group(6);
					String curDstPort=m.group(7);
					String curOption=m.group(8);
					//System.out.println(curZone+","+curAction+","+curProto+","+curSrcNet+","+curSrcPort+","+curDstNet+","+curDstPort+","+curOption);
					
					//事前処理
					LinkedList<String> befList;
					LinkedList<String> aftList;
					befList=new LinkedList<String>();
					befList.add(hostname+","+line+","+curInt+","+curZone+","+curAction);
					
					//プロトコル処理
					aftList=new LinkedList<String>();
					if(curProto.matches("object-group .*")){
						ObjectGroup curObjGrp=objectGroupMap.get(curProto.replace("object-group ",""));
						LinkedList<String> curOutputList=curObjGrp.getOutputStrList(objectGroupMap);
						for(String curStr:curOutputList){
							String commaAddedStr=commaAdd(curStr,2);
							//System.out.println(commaAddedStr);
							for(String curStr2:befList){
								aftList.add(curStr2+commaAddedStr);
							}
						}
					}else{
						String commaAddedStr=commaAdd(curProto,2);
						for(String curStr2:befList){
							aftList.add(curStr2+commaAddedStr);
						}
					}
					befList=aftList;
					
					//src net処理
					aftList=new LinkedList<String>();
					if(curSrcNet.matches("object-group .*")){
						ObjectGroup curObjGrp=objectGroupMap.get(curSrcNet.replace("object-group ",""));
						LinkedList<String> curOutputList=curObjGrp.getOutputStrList(objectGroupMap);
						for(String curStr:curOutputList){
							String commaAddedStr=commaAdd(curStr,5);
							//System.out.println(commaAddedStr);
							for(String curStr2:befList){
								aftList.add(curStr2+commaAddedStr);
							}
						}
					}else if(curSrcNet.equals("any")){
						String commaAddedStr=commaAdd(curSrcNet,5);
						for(String curStr2:befList){
							aftList.add(curStr2+commaAddedStr);
						}
					}else{
						System.out.println("想定外のsrc net:"+curSrcNet);
						System.exit(0);
					}
					befList=aftList;
					
					//src port処理
					aftList=new LinkedList<String>();
					if(curSrcPort==null){
						String commaAddedStr=",";
						for(String curStr2:befList){
							aftList.add(curStr2+commaAddedStr);
						}
						
					}else if(curSrcPort.matches(" eq .+?")){
						String commaAddedStr=commaAdd(curSrcPort.replace(" eq ",""),1);
						for(String curStr2:befList){
							aftList.add(curStr2+commaAddedStr);
						}
					}else if(curSrcPort.matches(" range .+? .+?")){
						String[] word1=curSrcPort.split(" ");
						String commaAddedStr=commaAdd(word1[2]+" - "+word1[3],1);
						for(String curStr2:befList){
							aftList.add(curStr2+commaAddedStr);
						}
					}else{
						System.out.println("想定外のsrc port:"+curSrcPort);
						System.exit(0);
					}
					befList=aftList;
					
					//dst net処理
					aftList=new LinkedList<String>();
					if(curDstNet.matches("object-group .*")){
						ObjectGroup curObjGrp=objectGroupMap.get(curDstNet.replace("object-group ",""));
						LinkedList<String> curOutputList=curObjGrp.getOutputStrList(objectGroupMap);
						for(String curStr:curOutputList){
							String commaAddedStr=commaAdd(curStr,5);
							//System.out.println(commaAddedStr);
							for(String curStr2:befList){
								aftList.add(curStr2+commaAddedStr);
							}
						}
					}else if(curDstNet.equals("any")){
						String commaAddedStr=commaAdd(curDstNet,5);
						for(String curStr2:befList){
							aftList.add(curStr2+commaAddedStr);
						}
					}else{
						System.out.println("想定外のdst net:"+curDstNet);
						System.exit(0);
					}
					befList=aftList;
					
					//dst port処理
					aftList=new LinkedList<String>();
					if(curDstPort==null){
						String commaAddedStr=",,,";
						for(String curStr2:befList){
							aftList.add(curStr2+commaAddedStr);
						}
						
					}else if(curDstPort.matches(" object-group .*")){
						ObjectGroup curObjGrp=objectGroupMap.get(curDstPort.replace(" object-group ",""));
						LinkedList<String> curOutputList=curObjGrp.getOutputStrList(objectGroupMap);
						for(String curStr:curOutputList){
							String commaAddedStr=commaAdd(curStr,3);
							//System.out.println(commaAddedStr);
							for(String curStr2:befList){
								aftList.add(curStr2+commaAddedStr);
							}
						}
					}else if(curDstPort.matches(" eq .+?")){
						String commaAddedStr=commaAdd(curDstPort.replace(" eq ",""),3);
						for(String curStr2:befList){
							aftList.add(curStr2+commaAddedStr);
						}
					}else if(curDstPort.matches(" range .+? .+?")){
						String[] word1=curDstPort.split(" ");
						String commaAddedStr=commaAdd(word1[2]+" - "+word1[3],3);
						for(String curStr2:befList){
							aftList.add(curStr2+commaAddedStr);
						}
					}else{
						System.out.println("想定外のdst port:"+curDstPort);
						System.exit(0);
					}
					befList=aftList;
					
					//オプション処理(最後)
					aftList=new LinkedList<String>();
					if(curOption==null){
						String commaAddedStr=",false";
						for(String curStr2:befList){
							aftList.add(curStr2+commaAddedStr);
						}
						
					}else if(curOption.equals(" log")){
						String commaAddedStr=",true";
						for(String curStr2:befList){
							aftList.add(curStr2+commaAddedStr);
						}
						
					}else{
						System.out.println("想定外のoption:"+curOption);
						System.exit(0);
					}
					
					//最終処理
					for(String curStr:aftList){
						outputList.add(curStr);
					}
					
				}else{
					System.out.println("想定外のaccess-list:"+line+":");
					System.exit(0);
				}
			}
			br.close();
			
			//設定が無いときは出力しない
			if(outputList.size()==0)continue;
			
			PrintWriter wr = new PrintWriter(new BufferedWriter(new OutputStreamWriter(new FileOutputStream("../11_asa_acl/"+hostname+"_ASAAcl.csv"),"Shift-JIS")));
			wr.println(headerStr);
			for(String curStr:outputList){
				wr.println(curStr);
			}
			wr.close();
		}
	}
	
	public static String commaAdd(String srcStr,int commaNum){
		String returnStr=srcStr;
		
		int commaSum=0;
		for(char curChar:srcStr.toCharArray()){
			if(curChar==',')commaSum++;
		}
		//System.out.println(srcStr+","+commaSum);
		for(int i=commaSum;i<commaNum;i++){
			returnStr=','+returnStr;
		}
		
		return returnStr;
	}
	
	//object groupマップ取得
	public static HashMap<String,ObjectGroup> getObjectGroupMap(File curFile) throws Exception{
		HashMap<String,ObjectGroup> objectGroupMap=new HashMap<String,ObjectGroup>();
		
		BufferedReader br = new BufferedReader(new FileReader(curFile));
		String line=null;
		String mode="OG_OUT";
		ObjectGroup curOG=null;
		while ((line = br.readLine()) != null){
			if(line.matches("object-group .*")){
				//System.out.println(line);
				//if(!line.matches("object-group (network|service|protocol) .*"))System.out.println(line);
				//if(curOG!=null)curOG.showAll();
				
				if(line.matches("object-group network .*")){
					//System.out.println(line);
					curOG=new ObjectGroup();
					curOG.setType("network");
					String[] word=line.split(" ");
					curOG.setName(word[2]);
					objectGroupMap.put(word[2],curOG);
					
				}else if(line.matches("object-group service .* .*")){
					//System.out.println(line);
					curOG=new ObjectGroup();
					curOG.setType("service");
					String[] word=line.split(" ");
					curOG.setName(word[2]);
					curOG.setProtocol(word[3]);
					objectGroupMap.put(word[2],curOG);
					
				}else if(line.matches("object-group protocol .*")){
					//System.out.println(line);
					curOG=new ObjectGroup();
					curOG.setType("protocol");
					String[] word=line.split(" ");
					curOG.setName(word[2]);
					objectGroupMap.put(word[2],curOG);
					
				}else{
					System.out.println("想定外のオブジェクトグループ:"+line);
					System.exit(0);
				}
				
				mode="OG_IN";
			}else if(mode.equals("OG_IN")){
				if(line.matches(" network-object .*")){
					//System.out.println(line);
					String[] word=line.split(" ");
					if(word[2].equals("host")){
						curOG.addNetwork(word[3],"255.255.255.255");
					}else{
						curOG.addNetwork(word[2],word[3]);
					}
					
				}else if(line.matches(" group-object .*")){
					//System.out.println(line);
					if(line.matches(" group-object .* .*")){
						System.out.println(line);
						System.exit(0);
					}
					
					String[] word=line.split(" ");
					curOG.addGroup(word[2]);
					
				}else if(line.matches(" port-object .*")){
					//System.out.println(line);
					String[] word=line.split(" ");
					if(word[2].equals("eq")){
						curOG.addPort(word[3]);
					}else if(word[2].equals("range")){
						curOG.addRange(word[3],word[4]);
					}else{
						System.out.println("想定外のport object:"+line);
						System.exit(0);
					}
					
				}else if(line.matches(" protocol-object (tcp|udp)")){
					//System.out.println(line);
					String[] word=line.split(" ");
					curOG.addProtocol(word[2]);
					
				}else{
					//System.out.println(line);
					//if(curOG!=null)curOG.showAll();
					break;
				}
			}
		}
		br.close();
		
		return objectGroupMap;
	}
	
	//機器のホスト名を取得
	public static String getHostname(File curFile) throws Exception{
		BufferedReader br = new BufferedReader(new FileReader(curFile));
		String line=null;
		String mode="START";
		while ((line = br.readLine()) != null) {
			//System.out.println(line);
			if(line.matches("hostname .*")){
				br.close();
				return line.replace("hostname ","");
			}else if(line.equals("/c/sys/ssnmp")){
				mode="LB_HOSTNAME";
			}else if(mode.equals("LB_HOSTNAME") && line.matches("\tname .*")){
				String hostname=line.replaceAll("\tname","");
				hostname=hostname.replaceAll("\"","");
				br.close();
				return hostname;
			}else if(line.matches("set system host-name .*")){
				br.close();
				return line.replace("set system host-name ","");
			}
		}
		br.close();
		
		return null;
	}
}