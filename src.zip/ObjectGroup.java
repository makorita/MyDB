import java.io.*;
import java.util.*;

public class ObjectGroup{
	/*
	[想定]
	子孫に別のtypeは混ざらない
	ObjectGroupを子に持つときnetworkやportなどはリストに入らない。グループ以外のリストに値が入るのは葉っぱの場合だけ。
	*/
	String name;
	String type;
	String protocol;	//serviceの場合。protocol typeのオブジェクトグループ名がくることもある。ex)tcp-udp
	LinkedList<Address> networkList;
	LinkedList<String> portList;
	LinkedList<String> protocolList;
	LinkedList<String> groupList;
	int maxLevel;
	
	public ObjectGroup(){
		networkList=new LinkedList<Address>();
		portList=new LinkedList<String>();
		protocolList=new LinkedList<String>();
		groupList=new LinkedList<String>();
		maxLevel=0;	//未定義
	}
	
	public String getName(){
		return name;
	}
	
	public void setName(String name){
		this.name=name;
	}
	
	public String getType(){
		return type;
	}
	
	public void setType(String type){
		this.type=type;
	}
	
	public String getProtocol(){
		return protocol;
	}
	
	public void setProtocol(String protocol){
		this.protocol=protocol;
	}
	
	public void addNetwork(String ip,String mask){
		Address curAddr=new Address(ip,mask);
		networkList.add(curAddr);
	}
	
	public void addGroup(String groupName){
		groupList.add(groupName);
	}
	
	public void addPort(String port){
		portList.add(port);
	}
	
	public void addRange(String startPort,String endPort){
		portList.add(startPort+" - "+endPort);
	}
	
	public void addProtocol(String protocol){
		protocolList.add(protocol);
	}
	
	public int getMaxLevel(int curLevel,HashMap<String,ObjectGroup> objectGroupMap){
		int tmpMaxLevel=curLevel;
		if(networkList.size()>0 || portList.size()>0 || protocolList.size()>0)tmpMaxLevel++;
		
		for(String curGrpName:groupList){
			ObjectGroup curObjGrp=objectGroupMap.get(curGrpName);
			int childLevel=curObjGrp.getMaxLevel(curLevel+1,objectGroupMap);
			if(childLevel>tmpMaxLevel)tmpMaxLevel=childLevel;
		}
		
		return tmpMaxLevel;
	}
	
	public int getMaxLevel(){	//調査済のmaxLevelを返す
		return maxLevel;
	}
	
	public void setMaxLevel(int maxLevel){
		this.maxLevel=maxLevel;
	}
	
	public LinkedList<String> getOutputStrList(HashMap<String,ObjectGroup> objectGroupMap){
		LinkedList<String> returnList=new LinkedList<String>();
		
		//リストはどれか1つのはず
		for(String curStr:protocolList){
			returnList.add(","+getName()+","+curStr);
		}
		
		for(Address curAddr:networkList){
			returnList.add(","+getName()+","+curAddr.getStrExp());
		}
		
		for(String curStr:portList){
			returnList.add(","+getName()+","+curStr);
		}
		
		for(String curGrpName:groupList){
			ObjectGroup curObjGrp=objectGroupMap.get(curGrpName);
			LinkedList<String> childOutputList=curObjGrp.getOutputStrList(objectGroupMap);
			for(String curStr:childOutputList){
				returnList.add(","+getName()+curStr);
			}
		}
		
		return returnList;
	}
	
	public void showListSize(){
		System.out.println("ntwList:"+networkList.size());
		System.out.println("portList:"+portList.size());
		System.out.println("protocolList:"+protocolList.size());
		System.out.println("groupList:"+groupList.size());
		System.out.println();
	}
	
	public void showAll(){
		System.out.println("name:"+getName());
		System.out.println("maxLevel:"+getMaxLevel());
		System.out.println("type:"+getType());
		System.out.println("protocol:"+getProtocol());
		for(Address curAddr:networkList){
			System.out.println("  ntw:"+curAddr);
		}
		for(String curStr:portList){
			System.out.println("  port:"+curStr);
		}
		for(String curStr:protocolList){
			System.out.println("  protocol:"+curStr);
		}
		for(String curStr:groupList){
			System.out.println("  grp:"+curStr);
		}
		System.out.println();
	}
}
