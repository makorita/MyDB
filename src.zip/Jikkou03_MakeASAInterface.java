import java.io.*;
import java.util.*;
import java.util.regex.*;

public class Jikkou03_MakeASAInterface{
	static String headerStr="ホスト名,インターフェース名,shutdown,description,speed,duplex,ip,mask,standby,securityLevel,nameif,vlan";
	
	public static void main(String[] args) throws Exception{
		//コンフィグリストの取得
		File rootDir=new File("../02_rawConfig");
		File[] configList=rootDir.listFiles();
		
		for(File curFile:configList){	//ファイル回し
			if(!curFile.getName().matches(".*FW.*"))continue;
			System.out.println(curFile.getName());	//処理ファイル名
			
			//ホスト名取得
			String hostname=getHostname(curFile);
			
			BufferedReader br = new BufferedReader(new FileReader(curFile));
			LinkedList<String> outputList=new LinkedList<String>();
			String line;
			String mode="IF_OUT";
			ASAI_F curIf=null;
			while ((line = br.readLine()) != null) {
				//System.out.println(line);
				if(mode.equals("IF_OUT") && line.matches("interface .*")){
					curIf=new ASAI_F();
					String ifName=line.replace("interface ","");
					curIf.setIfName(ifName);
					
					mode="IF_IN";
				}else if(mode.equals("IF_IN")){
					if(line.equals("!")){
						outputList.add(hostname+","+curIf.getOutputStr());
						mode="IF_OUT";
						
					}else if(line.equals(" shutdown")){
						curIf.setShutdown(true);
						
					}else if(line.matches(" description .*")){
						String tmpStr=line;
						tmpStr=tmpStr.replaceAll(",","<c>");
						tmpStr=tmpStr.replaceAll(" description ","");
						curIf.setDescription(tmpStr);
						
					}else if(line.matches(" speed .*")){
						String tmpStr=line;
						tmpStr=tmpStr.replaceAll(" speed ","");
						curIf.setSpeed(tmpStr);
						
					}else if(line.matches(" duplex .*")){
						String tmpStr=line;
						tmpStr=tmpStr.replaceAll(" duplex ","");
						curIf.setDuplex(tmpStr);
						
					}else if(line.matches(" ip address .* standby .*")){
						String[] word=line.split(" ");
						curIf.setIP(word[3]);
						curIf.setMask(word[4]);
						curIf.setStandby(word[6]);
						
					}else if(line.matches(" security-level .*")){
						String tmpStr=line;
						tmpStr=tmpStr.replaceAll(" security-level ","");
						curIf.setSecurityLevel(tmpStr);
						
					}else if(line.matches(" nameif .*")){
						String tmpStr=line;
						tmpStr=tmpStr.replaceAll(" nameif ","");
						curIf.setNameif(tmpStr);
						
					}else if(line.matches(" vlan .*")){
						String tmpStr=line;
						tmpStr=tmpStr.replaceAll(" vlan ","");
						curIf.setVlan(tmpStr);
						
					}
				}
			}
			br.close();
			
			//設定が無いときは出力しない
			if(outputList.size()==0)continue;
			
			PrintWriter wr = new PrintWriter(new BufferedWriter(new OutputStreamWriter(new FileOutputStream("../11_asa_interface/"+hostname+"_ASAInterface.csv"),"Shift-JIS")));
			wr.println(headerStr);
			for(String curStr:outputList){
				wr.println(curStr);
			}
			wr.close();
		}
	}
	
	//機器のホスト名を取得
	public static String getHostname(File curFile) throws Exception{
		BufferedReader br = new BufferedReader(new FileReader(curFile));
		String line=null;
		String mode="START";
		while ((line = br.readLine()) != null) {
			//System.out.println(line);
			if(line.matches("hostname .*")){
				br.close();
				return line.replace("hostname ","");
			}else if(line.equals("/c/sys/ssnmp")){
				mode="LB_HOSTNAME";
			}else if(mode.equals("LB_HOSTNAME") && line.matches("\tname .*")){
				String hostname=line.replaceAll("\tname","");
				hostname=hostname.replaceAll("\"","");
				br.close();
				return hostname;
			}else if(line.matches("set system host-name .*")){
				br.close();
				return line.replace("set system host-name ","");
			}
		}
		br.close();
		
		return null;
	}
}